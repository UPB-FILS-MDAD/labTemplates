package com.example.services03

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.util.Log

class ForegroundCounterService : Service() {

    private val TAG = "ForegroundCounterService"
    private var isCounting = true
    private var count = 0

    //TODO 3 #starting-a-foreground-service
    // override the onStartCommand and create a notification + start countingThread


    //TODO 3 #stoping-a-foreground-service
    // override the onDestroy



    private fun startCountingThread() {
        Thread {
            while (isCounting) {
                count++
                Thread.sleep(1000)
                // TODO 3
                //uncomment this line to call the notification update function
                //updateNotification()
            }
        }.start()
    }

    // TODO 3 #updating-data-in-the-notification
    // create the updateNotification() function that updates the notification with the value of the counter


    override fun onBind(intent: Intent?): IBinder? = null
}
