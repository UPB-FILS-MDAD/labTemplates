package com.example.services03

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class BackgroundCounterService : Service() {

    private val TAG = "BackgroundCounterService"
    private var isCounting = true
    private var count = 0

    // TODO 1 #starting-a-background-service
    //override the onStartCommand function and call the startCounting function inside


    // TODO 1 #stoping-a-background-service
    //override the onDestroy function


    private fun startCounting() {
        // TODO 2
        // Fix the issue from task 1
            keepCounting()
    }

    private fun keepCounting(){
        while (isCounting) {
            count++
            Log.d(TAG, "Count: $count")
            Thread.sleep(1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
