package com.example.services03

import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.services03.databinding.ActivityMainBinding
import android.Manifest

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isBound = false


    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (!isGranted) {
                Toast.makeText(this, "Notification permission is required for foreground service", Toast.LENGTH_SHORT).show()
            }
        }

    // TODO 4 #preparing-bound-service
    //  declare the quoteService
    private var quoteService: QuoteFetchService? = null


    // TODO 4 #preparing-bound-service
    //  create serviceConnection and use the function defined in the QuoteFetchService's Binder inner class to retrieve the quoteService instance


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Foreground Service
        binding.startForegroundServiceButton.setOnClickListener {
            // TODO 3 #starting-a-foreground-service
            // start the ForegroundCounterService
        }

        binding.stopForegroundServiceButton.setOnClickListener {
            // TODO 3 #stoping-a-foreground-service
            // stop the ForegroundCounterService
        }

        // Background Service
        binding.startBackgroundServiceButton.setOnClickListener {
            // TODO 1 #starting-a-background-service
            // start the BackgroundCounterService
        }


        binding.stopBackgroundServiceButton.setOnClickListener {
            // TODO 1 #stoping-a-background-service
            // stop the BackgroundCounterService
        }

        // Bound Service
        binding.bindServiceButton.setOnClickListener {
            // TODO 4 #binding-a-service
            //  bind QuoteFetchService
        }

        binding.unbindServiceButton.setOnClickListener {
            // TODO 4 #unbiding-a-service
            // unbind serviceConnection
        }

        binding.fetchQuoteButton.setOnClickListener {
            // TODO 4 #retrieving-data-from-the-bound-service
            // retrieve the (quote, author) pair from the quoteService using the getLatestQuote() function

            //uncomment this line
            // binding.quoteTextView.text = "\"$quote\"\n\n- $author"
        }
    }
}
